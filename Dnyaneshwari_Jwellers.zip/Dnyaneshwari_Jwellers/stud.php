<?php 
error_reporting(0);
  session_start();
   $con=mysqli_connect("localhost","root","");
     if($con==false)
     {
         die("error");
     }
     $_SESSION["p"]=$_POST["p1"];
     if(isset($_POST["p1"]))
     {
         header('location:booknow.php');
     }
     
     mysqli_close($con);
?>
<html>
  <head>
    <link rel="stylesheet" href="index.css">
    <style> 
      .bgimage
      {
        background-image:url(images/bgimage.jpg);
         
      }
      button
       {
          background-color:purple;
          border: 1;
          border-color: white;
          color: white;
          padding: 5%;
          text-align: center;
          font-family:Century Gothic;
       }  
       a
       {
         text-decoration:none;
       }
    </style>
      
  </head>
  <body>
    <font face="Century Gothic">
    <table width="100%" height="30%">
      <tr>
        <th width="20%">
        <img src="images/name2.png" loading="lazy" height="50%">
        </th>  
          <th width="60%">
            <center>
              <h1 ><u><font color="red">D</font>nya</u>neshwari <u><font color="red">J</font>we</u>llers  </h1>
              <h3 > Shrirampur:Taklibhan | Maharashtra | A.Nagar-413725</h3>
              <h3 >email:-dnyneshwarialankar@gmail.com &nbsp | &nbsp<font size="3"> GST-IN=07AAECR2971C1Z</font></h3> 
           </center>
          </th>
            <th width="20%">
              <img src="images/ganesha.png" loading="lazy" width="70%" > 
            </th>
      </tr>
    </table>
    
    <hr size="2%" width="100%" color="baby pink">
  
    <table  width="70%">
      <tr>
        <th><a href="index.php">Home</a></th>
        <th> <div class="dropdown">
              &nbsp&nbsp  <font color="purple"> Gold  </font> &nbsp&nbsp
              <div class="dropdown-content">
              <a href="stud.php">Studs</a>
              <a href="mangalsutra.php">Mangalsutra</a>
              <a href="necklace.php">Necklace</a>
              <a href="pendant.php">Pendant</a>
              </div>
         </div>
        </th>
        <th> 

        <div class="dropdown">
              &nbsp&nbsp <font color="purple">  Diamond  </font>  &nbsp&nbsp
              <div class="dropdown-content">
              <a href="d_stud.php">Studs</a>
              <a href="d_mangalsutra.php">Mangalsutra</a>
              <a href="d_rings.php">Rings</a>
              <a href="d_necklace.php">Necklace</a>
              </div>
         </div>

        </th>
        <th>

        <div class="dropdown">
              &nbsp&nbsp <font color="purple">  Silver  </font>  &nbsp&nbsp
              <div class="dropdown-content">
              <a href="Painjan.php">Painjan</a>
              <a href="rakhi.php">Silver Rakhi</a>
              </div>
         </div>

        </th>

        <th> <a href="https://bullions.co.in/"> &nbsp&nbsp  <font color="purple"> Online rates </font> &nbsp&nbsp </a> </th>
        <th> <a href="contact.php"> &nbsp&nbsp  <font color="purple"> Contact & Support </font> &nbsp&nbsp </a> </th>
        <th> <div class="dropdown">
              &nbsp&nbsp  <font color="purple"> Account  </font> &nbsp&nbsp
              <div class="dropdown-content">
              <a href="login.php">User</a>
              <a href="admin_login.php">Admin</a>
        
      </tr> 
    </table>
          
            <hr size="3%" width="100%" color="baby pink">
        
            
            
        <center>
          <form method="POST" action="">
        <table width="70%" cellspacing="20">
            <tr>
                <th><img src="stud-images/s1.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s2.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s3.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s4.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Ellipse Flora Gold Earring<br>-<b>₹19,702</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Whorl Beauty Gold Stud Earring<br>-<b>₹28,546</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Peacock charm Gold Stud Earring<br>-<b>₹16,814</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Textured Gold Stud<br>-<b>₹52,593</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="1">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="2">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="3">Book Now</button></th>
                <th align="center"><button type="submit"name="p1" value="4">Book Now </button></th>
              </tr>
            <tr>
                <th><img src="stud-images/s5.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s6.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s7.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s8.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Trendy Groovy Stud<br>-<b>₹35,062</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Half Circulate Gold Stud Earring<br>-<b>₹23,488</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Leaflet Charm Gold Stud Earring<br>-<b>₹20,116</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Lamina Diamond Studded Gold Earring<br>-<b>₹26,380</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="5">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="6">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="7">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="8">Book Now</button></th>
              </tr>
              <tr>
                <th><img src="stud-images/s9.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s10.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s11.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s12.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Architectural Delight Gold Stud Earring<br>-<b>₹27,141</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Circular Dreamcatcher Gold Stud Earring<br>-<b>₹30,373</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Forest Symphony Gold Stud Earring<br>-<b>₹19,110</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Graceful Tearlet Gold Stud Earring<br>-<b>₹16,703</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="9">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="10">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="11">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="12">Book Now</button></th>
              </tr>
            
        </table>
          </form>
        </center>

        <hr size="2%" width="100%" color="purple">
        <div class="bgimage">
          <table   width="100%" height="30%">
            <tr>
              <th width="25%"><img src="images/weaccept.png" width="100%"></th>
              <th width="50%">
                 <h4><font color="gray">
                  copyright@dnyneshwarijewells-2024
                  you agree to the Terms of Use and Privacy Policy.
              dnyneshwarijewells® is a registered trademark of the (BSI) Foundation, Inc., Gold organization.
                 </font></h4>
              </th>
              <th width="25%"><h4 ><font color="gray"><u>Con</u>nect With us..</font></h4>
                              <a href="https://www.instagram.com/dnyaneshwari_jwellers00/"><img src="images/ig.png" width="10%"></a>
                              <a href="https://www.facebook.com/"><img src="images/fb.png" width="10%"></a>
                              <a href="https://twitter.com/?lang=en"><img src="images/twit.png" width="10%"></a>
                              <a href="https://in.linkedin.com/"><img src="images/in.png" width="10%"></a>
              </th>
            </tr>
          </table>  
          </div>
        </font>
          </center>
          <hr size="2%" width="100%" color="purple">
    </body>
</html>

<?php 
error_reporting(0);
  session_start();
   $con=mysqli_connect("localhost","root","");
     if($con==false)
     {
         die("error");
     }
     $_SESSION["p"]=$_POST["p1"];
     if(isset($_POST["p1"]))
     {
         header('location:booknow.php');
     }
     
     mysqli_close($con);
?>
<html>
  <head>
    <link rel="stylesheet" href="index.css">
    <style> 
      .bgimage
      {
        background-image:url(images/bgimage.jpg);
         
      }
      button
       {
          background-color:purple;
          border: 1;
          border-color: white;
          color: white;
          padding: 5%;
          text-align: center;
          font-family:Century Gothic;
       }  
       a
       {
         text-decoration:none;
       }
    </style>
      
  </head>
  <body>
    <font face="Century Gothic">
    <table width="100%" height="30%">
      <tr>
        <th width="20%">
        <img src="images/name2.png" loading="lazy" height="50%">
        </th>  
          <th width="60%">
            <center>
              <h1 ><u><font color="red">D</font>nya</u>neshwari <u><font color="red">J</font>we</u>llers  </h1>
              <h3 > Shrirampur:Taklibhan | Maharashtra | A.Nagar-413725</h3>
              <h3 >email:-dnyneshwarialankar@gmail.com &nbsp | &nbsp<font size="3"> GST-IN=07AAECR2971C1Z</font></h3> 
           </center>
          </th>
            <th width="20%">
              <img src="images/ganesha.png" loading="lazy" width="70%" > 
            </th>
      </tr>
    </table>
    
    <hr size="2%" width="100%" color="baby pink">
  
    <table  width="70%">
      <tr>
        <th><a href="index.php">Home</a></th>
        <th> <div class="dropdown">
              &nbsp&nbsp  <font color="purple"> Gold  </font> &nbsp&nbsp
              <div class="dropdown-content">
              <a href="stud.php">Studs</a>
              <a href="mangalsutra.php">Mangalsutra</a>
              <a href="necklace.php">Necklace</a>
              <a href="pendant.php">Pendant</a>
              </div>
         </div>
        </th>
        <th> 

        <div class="dropdown">
              &nbsp&nbsp <font color="purple">  Diamond  </font>  &nbsp&nbsp
              <div class="dropdown-content">
              <a href="d_stud.php">Studs</a>
              <a href="d_mangalsutra.php">Mangalsutra</a>
              <a href="d_rings.php">Rings</a>
              <a href="d_necklace.php">Necklace</a>
              </div>
         </div>

        </th>
        <th>

        <div class="dropdown">
              &nbsp&nbsp <font color="purple">  Silver  </font>  &nbsp&nbsp
              <div class="dropdown-content">
              <a href="Painjan.php">Painjan</a>
              <a href="rakhi.php">Silver Rakhi</a>
              </div>
         </div>

        </th>

        <th> <a href="https://bullions.co.in/"> &nbsp&nbsp  <font color="purple"> Online rates </font> &nbsp&nbsp </a> </th>
        <th> <a href="contact.php"> &nbsp&nbsp  <font color="purple"> Contact & Support </font> &nbsp&nbsp </a> </th>
        <th> <div class="dropdown">
              &nbsp&nbsp  <font color="purple"> Account  </font> &nbsp&nbsp
              <div class="dropdown-content">
              <a href="login.php">User</a>
              <a href="admin_login.php">Admin</a>
        
      </tr> 
    </table>
            </center>
            <hr size="3%" width="100%" color="baby pink">
        
            
        <center>
        <form method="POST" action="">
        <table width="70%" cellspacing="20">
        <tr>
                <th><img src="Diamond-mangalsutra/n1.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-mangalsutra/n2.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-mangalsutra/n3.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-mangalsutra/n4.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Crystalline Diamond Tanmaniya<br>-<b>₹40,060</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Designer Knot Diamond Tanmaniya<br>-<b>₹44,211</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Classy Diamond Tanmaniya<br>-<b>₹65,926</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Knotted Paisley Diamond Tanmaniya<br>-<b>₹24,695</b></font></th>
            </tr>
            <tr>
                <th align="center"><button type="submit" name="p1" value="57">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="58">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="59">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="60">Book Now</button></th>
            </tr>
            <tr>
                <th><img src="Diamond-mangalsutra/n5.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-mangalsutra/n6.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-mangalsutra/n7.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-mangalsutra/n8.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Gorgeous Vale Diamond Tanmaniya<br>-<b>₹53,649</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Wide Ray Design Tanmaniya<br>-<b>₹51,071</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Glam Diamond Tanmaniya<br>-<b>₹60,393</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Princess Diamond Tanmaniya<br>-<b>₹19,806</b></font></th>
            </tr>
            <tr>
                <th align="center"><button type="submit" name="p1" value="61">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="62">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="63">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="64">Book Now</button></th>
            </tr>
            <tr>
                <th><img src="Diamond-mangalsutra/n9.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-mangalsutra/n10.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-mangalsutra/n11.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-mangalsutra/n12.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Star Diamond Tanmaniya<br>-<b>₹21,568</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Star Arch Diamond Tanmaniya<br>-<b>₹32,414</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Ivy Diamond Tanmaniya<br>-<b>₹33,983</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Floral Layered Diamond Tanmaniya<br>-<b>₹44,505</b></font></th>
            </tr>
            <tr>
                <th align="center"><button type="submit" name="p1" value="65">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="66">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="67">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="68">Book Now</button></th>
              </tr>
              <tr>
                <th><img src="Diamond-necklace/n1.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-necklace/n2.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-necklace/n3.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-necklace/n4.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Infinity Floral Diamond Necklace<br>-<b>₹15,286</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Leaflet Diamond Necklace<br>-<b>₹13,427</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Fancy Floret Diamond Necklace<br>-<b>₹22,208</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Unfettered Teardrop Diamond Necklace<br>-<b>₹32,008</b></font></th>
            </tr>
            <tr>
                <th align="center"><button type="submit" name="p1" value="77">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="78">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="79">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="80">Book Now</button></th>
            </tr>
            <tr>
                <th><img src="Diamond-necklace/n5.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-necklace/n6.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-necklace/n7.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-necklace/n8.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Dainty Daisy Diamond Necklace<br>-<b>₹46,958</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Delicate Waves Diamond Necklace<br>-<b>₹20,812</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Sheeny Sunflower Diamond Necklace<br>-<b>₹31,023</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Lovely Leaf Diamond Necklace<br>-<b>₹19,636</b></font></th>
            </tr>
            <tr>
                <th align="center"><button type="submit" name="p1" value="81">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="82">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="83">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="84">Book Now</button></th>
              </tr>
              <tr>
                <th><img src="Diamond-rings/r1.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-rings/r2.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-rings/r3.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-rings/r4.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Epic Harmony Diamond Ladies Ring<br>-<b>₹57,783</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Stylish Swivel Diamond Ladies Ring<br>-<b>₹22,618</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Lily Luster Diamond Ring<br>-<b>₹19,974</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Cluster Hold Diamond Ring<br>-<b>₹19,360</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="69">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="70">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="71">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="72">Book Now</button></th>
              </tr>
            <tr>
                <th><img src="Diamond-rings/r5.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-rings/r6.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-rings/r7.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="Diamond-rings/r8.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Floral Knot Diamond Ring<br>-<b>₹25,529</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Majesty of Heart Diamond Ladies Ring<br>-<b>₹18,898</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Heartbeat Amulet Diamond Ladies Ring<br>-<b>₹18,564</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Endless Love Diamond Ladies Ring<br>-<b>₹15,700</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="73">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="74">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="75">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="76">Book Now</button></th>
              </tr>
              <tr>
                <th><img src="diamond-studs/d1.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="diamond-studs/d2.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="diamond-studs/d3.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="diamond-studs/d4.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Blooming Bud Diamond Stud Earrings<br>-<b>₹27,072</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Fuchsia Fantasy Diamond Earring<br>-<b>₹52,744</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Pristine Dews Diamond Pendant<br>-<b>₹13,570</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Petal Enchantment Diamond Studs Earring<br>-<b>₹30,934</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="45">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="46">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="47">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="48">Book Now</button></th>
              </tr>
            <tr>
                <th><img src="diamond-studs/d5.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="diamond-studs/d6.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="diamond-studs/d7.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="diamond-studs/d8.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Charming Floral Diamond Studs Earring<br>-<b>₹25,783</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Eyeconic Boom Diamond Studs Earring<br>-<b>₹28,020</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Space-Age Swastik Diamond Stud Earrings<br>-<b>₹23,719</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Geo Artistry Diamond Studs Earring<br>-<b>₹19,028</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="49">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="50">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="51">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="52">Book Now</button></th>
              </tr>
              <tr>
                <th><img src="diamond-studs/d9.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="diamond-studs/d10.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="diamond-studs/d11.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="diamond-studs/d12.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Threefold Petals Diamond Studs Earring<br>-<b>₹18,044</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Solitary Rosebud Diamond Studs Earring<br>-<b>₹18,019</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Linear Elegance Diamond Studs Earring<br>-<b>₹33,134</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Twinkling Twist Diamond Stud Earrings<br>-<b>₹16,465</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="53">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="54">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="55">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="56">Book Now</button></th>
              </tr>
           
        </table>
        </form>
        </center>

        <hr size="2%" width="100%" color="purple">
        <div class="bgimage">
          <table   width="100%" height="30%">
            <tr>
              <th width="25%"><img src="images/weaccept.png" width="100%"></th>
              <th width="50%">
                 <h4><font color="gray">
                  copyright@dnyneshwarijewells-2024
                  you agree to the Terms of Use and Privacy Policy.
              dnyneshwarijewells® is a registered trademark of the (BSI) Foundation, Inc., Gold organization.
                 </font></h4>
              </th>
              <th width="25%"><h4 ><font color="gray"><u>Con</u>nect With us..</font></h4>
                              <a href="https://www.instagram.com/dnyaneshwari_jwellers00/"><img src="images/ig.png" width="10%"></a>
                              <a href="https://www.facebook.com/"><img src="images/fb.png" width="10%"></a>
                              <a href="https://twitter.com/?lang=en"><img src="images/twit.png" width="10%"></a>
                              <a href="https://in.linkedin.com/"><img src="images/in.png" width="10%"></a>
              </th>
            </tr>
          </table>  
          </div>
        </font>
          </center>
          <hr size="2%" width="100%" color="purple">
    </body>
</html>
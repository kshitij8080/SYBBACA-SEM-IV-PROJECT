<html>
<head>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f4f4f4;
    }
    nav {
        background-color:#333;
        color: #fff;
        text-align: center;
        padding: 10px 0;
        border-radius:50px;
        
    }
    nav a {
        color: #fff;
        text-decoration: none;
        padding: 10px 20px;
        margin: 0 5px;
        border-radius: 50px;
        transition: background-color 0.3s ease;
    }
    nav a:hover {
        background-color: #555;
        border-radius:50px;
    }
    .container {
        max-width: 800px;
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .tab-content {
        display: none;
    }
    a{
      text-decoration:none;
    }
    
</style>
</head>
<body>

<font face="Century Gothic">
    <table width="100%" height="30%">
      <tr>
        <th width="20%">
        <img src="images/name2.png" loading="lazy" height="50%">
        </th>  
          <th width="60%">
            <center>
              <h1 ><u><font color="red">D</font>nya</u>neshwari <u><font color="red">J</font>we</u>llers  </h1>
              <h3 > Shrirampur:Taklibhan | Maharashtra | A.Nagar-413725</h3>
              <h3 >email:-dnyneshwarialankar@gmail.com &nbsp | &nbsp<font size="3"> GST-IN=07AAECR2971C1Z</font></h3> 
           </center>
          </th>
            <th width="20%">
              <img src="images/ganesha.png" loading="lazy" width="70%" > 
            </th>
      </tr>
    </table>
</font>

<hr size="3%" width="100%" color="baby pink">
<h1 align="center"><font color="red">W</font>elcome <font color="red">A</font>dmin</h1>
<hr size="3%" width="100%" color="baby pink">

<nav>
    <label for="contact-details"><a href="contact_info.php">Contact Details</a></label>
</nav><br>

<nav>
    <label for="login-details"><a href="login_info.php">Login Details</a></label>
</nav><br>

<nav>
    <label for="order-details"><a href="booking_details.php">Booking Details</a></label>
</nav><br>
<nav>
<label for="log-out"><a href="admin_login.php"><b><u>Log-Out</u><b></a></label>
</nav><br>

</body>
</html>

<?php 
error_reporting(0);
  session_start();
   $con=mysqli_connect("localhost","root","");
     if($con==false)
     {
         die("error");
     }
     $_SESSION["p"]=$_POST["p1"];
     if(isset($_POST["p1"]))
     {
         header('location:booknow.php');
     }
     
     mysqli_close($con);
?>
<html>
  <head>
    <link rel="stylesheet" href="index.css">
    <style> 
      .bgimage
      {
        background-image:url(images/bgimage.jpg);
         
      }
      button
       {
          background-color:purple;
          border: 1;
          border-color: white;
          color: white;
          padding: 5%;
          text-align: center;
          font-family:Century Gothic;
       }  
       a
       {
         text-decoration:none;
       }
    </style>
      
  </head>
  <body>
    <font face="Century Gothic">
    <table width="100%" height="30%">
      <tr>
        <th width="20%">
        <img src="images/name2.png" loading="lazy" height="50%">
        </th>  
          <th width="60%">
            <center>
              <h1 ><u><font color="red">D</font>nya</u>neshwari <u><font color="red">J</font>we</u>llers  </h1>
              <h3 > Shrirampur:Taklibhan | Maharashtra | A.Nagar-413725</h3>
              <h3 >email:-dnyneshwarialankar@gmail.com &nbsp | &nbsp<font size="3"> GST-IN=07AAECR2971C1Z</font></h3> 
           </center>
          </th>
            <th width="20%">
              <img src="images/ganesha.png" loading="lazy" width="70%" > 
            </th>
      </tr>
    </table>
    
    <hr size="2%" width="100%" color="baby pink">
  
    <table  width="70%">
      <tr>
        <th><a href="index.php">Home</a></th>
        <th> <div class="dropdown">
              &nbsp&nbsp  <font color="purple"> Gold  </font> &nbsp&nbsp
              <div class="dropdown-content">
              <a href="stud.php">Studs</a>
              <a href="mangalsutra.php">Mangalsutra</a>
              <a href="necklace.php">Necklace</a>
              <a href="pendant.php">Pendant</a>
              </div>
         </div>
        </th>
        <th> 

        <div class="dropdown">
              &nbsp&nbsp <font color="purple">  Diamond  </font>  &nbsp&nbsp
              <div class="dropdown-content">
              <a href="d_stud.php">Studs</a>
              <a href="d_mangalsutra.php">Mangalsutra</a>
              <a href="d_rings.php">Rings</a>
              <a href="d_necklace.php">Necklace</a>
              </div>
         </div>

        </th>
        <th>

        <div class="dropdown">
              &nbsp&nbsp <font color="purple">  Silver  </font>  &nbsp&nbsp
              <div class="dropdown-content">
              <a href="Painjan.php">Painjan</a>
              <a href="rakhi.php">Silver Rakhi</a>
              </div>
         </div>

        </th>

        <th> <a href="https://bullions.co.in/"> &nbsp&nbsp  <font color="purple"> Online rates </font> &nbsp&nbsp </a> </th>
        <th> <a href="contact.php"> &nbsp&nbsp  <font color="purple"> Contact & Support </font> &nbsp&nbsp </a> </th>
        <th> <div class="dropdown">
              &nbsp&nbsp  <font color="purple"> Account  </font> &nbsp&nbsp
              <div class="dropdown-content">
              <a href="login.php">User</a>
              <a href="admin_login.php">Admin</a>
        
      </tr> 
    </table>
          </center>
            <hr size="3%" width="100%" color="baby pink">
        
            
            
        <center>
          <form method="POST" action="">
          <table width="70%" cellspacing="20">
            <tr>
                <th><img src="stud-images/s1.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s2.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s3.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s4.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Ellipse Flora Gold Earring<br>-<b>₹19,702</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Whorl Beauty Gold Stud Earring<br>-<b>₹28,546</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Peacock charm Gold Stud Earring<br>-<b>₹16,814</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Textured Gold Stud<br>-<b>₹52,593</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="1">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="2">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="3">Book Now</button></th>
                <th align="center"><button type="submit"name="p1" value="4">Book Now </button></th>
              </tr>
            <tr>
                <th><img src="stud-images/s5.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s6.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s7.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s8.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Trendy Groovy Stud<br>-<b>₹35,062</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Half Circulate Gold Stud Earring<br>-<b>₹23,488</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Leaflet Charm Gold Stud Earring<br>-<b>₹20,116</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Lamina Diamond Studded Gold Earring<br>-<b>₹26,380</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="5">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="6">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="7">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="8">Book Now</button></th>
              </tr>
              <tr>
                <th><img src="stud-images/s9.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s10.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s11.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="stud-images/s12.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Architectural Delight Gold Stud Earring<br>-<b>₹27,141</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Circular Dreamcatcher Gold Stud Earring<br>-<b>₹30,373</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Forest Symphony Gold Stud Earring<br>-<b>₹19,110</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Graceful Tearlet Gold Stud Earring<br>-<b>₹16,703</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="9">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="10">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="11">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="12">Book Now</button></th>
              </tr>

              <tr>
                <th><img src="necklace-images/n1.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="necklace-images/n2.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="necklace-images/n3.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="necklace-images/n4.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Swarajya 22KT Gold Mohan Mal Necklace<br>-<b>₹3,03,042</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Swarajya Gold Kolhapuri Saj Necklace<br>-<b>₹20,93,573</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Swarajya Gold Kolhapuri Saj Necklace<br>-<b>₹12,29,119</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Swarajya Gold Mohan Mal with Pendent Necklace<br>-<b>₹4,07,260</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="25">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="26">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="27">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="28">Book Now</button></th>
              </tr>
            <tr>
                <th><img src="necklace-images/n5.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="necklace-images/n6.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="necklace-images/n7.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="necklace-images/n8.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Swarajya Gold Laxmi Har Necklace<br>-<b>₹1,68,449</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Swarajya Gold Bormal Necklace<br>-<b>₹68,087</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Swarajya Gold Mohan Mal Necklace<br>-<b>₹14,47,424</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Swarajya Gold Bakuli Har Necklace<br>-<b>₹4,07,592</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="29">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="30">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="31">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="32">Book Now</button></th>
              </tr>
              <tr>
                <th><img src="mangalsutra-images/m1.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="mangalsutra-images/m2.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="mangalsutra-images/m3.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="mangalsutra-images/m4.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Spheric Beauty Gold Mangalsutra<br>-<b>₹52,645</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Beaded Beauty Gold Mangalsutra<br>-<b>₹25,048</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Simply Archaic Gold Mangalsutra<br>-<b>₹52,272</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Clover Charm Gold Mangalsutra<br>-<b>₹50,692</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="13">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="14">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="15">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="16">Book Now</button></th>
              </tr>
            <tr>
                <th><img src="mangalsutra-images/m5.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="mangalsutra-images/m6.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="mangalsutra-images/m7.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="mangalsutra-images/m8.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Heartly Vintage Gold Mangalsutra<br>-<b>₹49,112</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Pristine Pearl Gold Mangalsutra<br>-<b>₹38,172</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Opulent Orb Mangalsutra<br>-<b>₹52,318</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Radiant Blossom 22k Gold Mangalsutra<br>-<b>₹67,575</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="17">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="18">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="19">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="20">Book Now</button></th>
              </tr>
              <tr>
                <th><img src="mangalsutra-images/m9.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="mangalsutra-images/m10.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="mangalsutra-images/m11.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="mangalsutra-images/m12.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Timeless Black Bead 22k Gold Mangalsutra<br>-<b>₹38,594</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Starfire Embrace 22k Gold Mangalsutra<br>-<b>₹37,063</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Heavenly Heart 18k Gold Mangalsutra<br>-<b>₹30,567</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Tiny Quad Gold Mangalsutra<br>-<b>₹39,391</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="21">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="22">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="23">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="24">Book Now</button></th>
              </tr>
              <tr>
                <th><img src="pendant-images/p1.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="pendant-images/p2.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="pendant-images/p3.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="pendant-images/p4.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Celestial Botanical Gold Pendant<br>-<b>₹19,618</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Groovy Architectural Charm Gold Pendant<br>-<b>₹34,227</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Singular Majestic Drop Gold Pendant<br>-<b>₹12,522</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Jazzy Leafy Charm Gold Pendant<br>-<b>₹10,853</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="33">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="34">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="35">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="36">Book Now</button></th>
              </tr>
            <tr>
                <th><img src="pendant-images/p5.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="pendant-images/p6.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="pendant-images/p7.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="pendant-images/p8.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Radiant Unique Charm Gold Pendant<br>-<b>₹20,036</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Twining-bud Wonder Gold Pendant<br>-<b>₹12,522</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Graceful Hexagon Gold Pendant<br>-<b>₹15,966</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Ellipse Floral Charm Gold Pendant<br>-<b>₹22,540</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="37">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="38">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="39">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="40">Book Now</button></th>
              </tr>
              <tr>
                <th><img src="pendant-images/p9.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="pendant-images/p10.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="pendant-images/p11.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="pendant-images/p12.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">A pendant Custom Design<br>-<b>₹16,078</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Distinct Whisper Flora Gold Pendant<br>-<b>₹9,183</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Nature Clusteral Charm Gold Pendant<br>-<b>₹22,540</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Orbital Splendor Gold Pendant<br>-<b>₹33,393</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="41">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="42">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="43">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="44">Book Now</button></th>
              </tr>
            
            
        </table>
        
          </form>
        </center>

        <hr size="2%" width="100%" color="purple">
        <div class="bgimage">
          <table   width="100%" height="30%">
            <tr>
              <th width="25%"><img src="images/weaccept.png" width="100%"></th>
              <th width="50%">
                 <h4><font color="gray">
                  copyright@dnyneshwarijewells-2024
                  you agree to the Terms of Use and Privacy Policy.
              dnyneshwarijewells® is a registered trademark of the (BSI) Foundation, Inc., Gold organization.
                 </font></h4>
              </th>
              <th width="25%"><h4 ><font color="gray"><u>Con</u>nect With us..</font></h4>
                              <a href="https://www.instagram.com/dnyaneshwari_jwellers00/"><img src="images/ig.png" width="10%"></a>
                              <a href="https://www.facebook.com/"><img src="images/fb.png" width="10%"></a>
                              <a href="https://twitter.com/?lang=en"><img src="images/twit.png" width="10%"></a>
                              <a href="https://in.linkedin.com/"><img src="images/in.png" width="10%"></a>
              </th>
            </tr>
          </table>  
          </div>
        </font>
          </center>
          <hr size="2%" width="100%" color="purple">
    </body>
</html>
<?php
   $con=mysqli_connect("localhost","root","");
     if($con==false)
     {
         die("error");
     }
     $pid=$_POST["p1"];
     mysqli_select_db($con,"project");
     $res=mysqli_query($con,"select * from product where pid='$pid'");
     while($row=mysqli_fetch_array($res))
     {
        echo"<br>".$row['pname'];
     }
     mysqli_close($con);

       


?>
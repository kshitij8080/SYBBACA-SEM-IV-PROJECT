<html>
<head>
<style>
   #border{
    tr:nth-child(odd){
        background-color:#f5f6f5;
         }
         tr:nth-child(even){
        background-color:#e1e3e1;
        border-color:black;
      }
   }
</style>
</head>
<body>
<font face="Century Gothic">
    <table width="100%" height="30%">
      <tr>
        <th width="20%">
        <img src="images/name2.png" loading="lazy" height="50%">
        </th>  
          <th width="60%">
            <center>
              <h1 ><u><font color="red">D</font>nya</u>neshwari <u><font color="red">J</font>we</u>llers  </h1>
              <h3 > Shrirampur:Taklibhan | Maharashtra | A.Nagar-413725</h3>
              <h3 >email:-dnyneshwarialankar@gmail.com &nbsp | &nbsp<font size="3"> GST-IN=07AAECR2971C1Z</font></h3> 
           </center>
          </th>
            <th width="20%">
              <img src="images/ganesha.png" loading="lazy" width="70%" > 
            </th>
      </tr>
    </table>
</font>
<hr size="3%" width="100%" color="baby pink">
<h1 align="center"><font color="red">l</font>ogin <font color="red">D</font>etails</h1>
<hr size="3%" width="100%" color="baby pink"><br>
</html>
<?php
    $con=mysqli_connect("localhost","root","");
    if($con==false)
    {
        die("error in conection");
    }
    mysqli_select_db($con,"project");
    $res=mysqli_query($con,"select * from login");
    echo"<table border='1' width='100%' height='5%'>";
    echo"<tr id='firstrow'><th width='20%'>Userame</th><th>Email</th><th>Password</th></tr>";
     while($row=mysqli_fetch_array($res))
     {
        echo"<tr><td align='center'>".$row['username'];
        echo"<td align='center'>".$row['email'];
        echo"<td align='center'>".$row['password'];
        echo"</tr>";
     }
     echo"</table>";
     echo"<br>";
     echo"<a href='index.php'>Back to Home...!</a>";
?>
<?php
   
   $con=mysqli_connect("localhost","root","");
   if($con==false)
   {
     die("error in connection...");
   }
  if(isset($_POST["t4"]))
{
    $n=$_POST["t1"];
    $em=$_POST["t2"];
    $msg=$_POST["t3"];

    mysqli_select_db($con,"project");
     $res=mysqli_query($con,"insert into contact values('$n','$em','$msg')");

     if($res==true)
     {
      echo"<script>alert('Thanks for contact us...')
      window.location.href='index.php'; </script>";  
      exit();
     }
}
 mysqli_close($con);
?>

<html>
<head>
<link rel="stylesheet" href="index.css">
    <title>Jewelry Shop - Contact & Support</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
         .contact
         {
            background-image: url(images/bgimg.jpg);
         }
        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1em 0;
        }

        section {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            display: grid;
            grid-gap: 15px;
        }

        label {
            font-weight: bold;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: purple;
        }
        a
       {
         text-decoration:none;
       }
       .bgimage
      {
        background-image:url(images/bgimage.jpg);
         
      }
    </style>
</head>
<body>


<font face="Century Gothic">
<table width="100%" height="30%">
      <tr>
        <th width="20%">
        <img src="images/name2.png" loading="lazy" height="50%">
        </th>  
          <th width="60%">
            <center>
              <h1 ><u><font color="red">D</font>nya</u>neshwari <u><font color="red">J</font>we</u>llers  </h1>
              <h3 > Shrirampur:Taklibhan | Maharashtra | A.Nagar-413725</h3>
              <h3 >email:-dnyneshwarialankar@gmail.com &nbsp | &nbsp<font size="3"> GST-IN=07AAECR2971C1Z</font></h3> 
           </center>
          </th>
            <th width="20%">
              <img src="images/ganesha.png" loading="lazy" width="70%" > 
            </th>
      </tr>
    </table>
    
    <hr size="2%" width="100%" color="baby pink">
  
    <table  width="70%">
      <tr>
        <th><a href="index.php">Home</a></th>
        <th> <div class="dropdown">
              &nbsp&nbsp  <font color="purple"> Gold  </font> &nbsp&nbsp
              <div class="dropdown-content">
              <a href="stud.php">Studs</a>
              <a href="mangalsutra.php">Mangalsutra</a>
              <a href="necklace.php">Necklace</a>
              <a href="pendant.php">Pendant</a>
              </div>
         </div>
        </th>
        <th> 

        <div class="dropdown">
              &nbsp&nbsp <font color="purple">  Diamond  </font>  &nbsp&nbsp
              <div class="dropdown-content">
              <a href="d_stud.php">Studs</a>
              <a href="d_mangalsutra.php">Mangalsutra</a>
              <a href="d_rings.php">Rings</a>
              <a href="d_necklace.php">Necklace</a>
              </div>
         </div>

        </th>
        <th>

        <div class="dropdown">
              &nbsp&nbsp <font color="purple">  Silver  </font>  &nbsp&nbsp
              <div class="dropdown-content">
              <a href="Painjan.php">Painjan</a>
              <a href="rakhi.php">Silver Rakhi</a>
              </div>
         </div>

        </th>

        <th> <a href="https://bullions.co.in/"> &nbsp&nbsp  <font color="purple"> Online rates </font> &nbsp&nbsp </a> </th>
        <th> <a href="contact.php"> &nbsp&nbsp  <font color="purple"> Contact & Support </font> &nbsp&nbsp </a> </th>
        <th> <div class="dropdown">
              &nbsp&nbsp  <font color="purple"> Account  </font> &nbsp&nbsp
              <div class="dropdown-content">
              <a href="login.php">User</a>
              <a href="admin_login.php">Admin</a>        
      </tr> 
    </table>
    <hr size="2%" width="100%" color="baby pink">
    </font>


    
   <div class="contact">
    <section>
        <h2>Contact Us</h2>
        <form action="#" method="post">
            <label for="name">Name:</label>
            <input type="text" name="t1" required>

            <label for="email">Email:</label>
            <input type="email" name="t2" required>

            <label for="message">Message:</label>
            <textarea name="t3" rows="4" required></textarea>

           <button name="t4">Submit</button>
        </form>
    </section>

    <section>
        <h2>Customer Support</h2>
        <p>If you have any questions or need assistance, please contact our customer support team at Dnyaneshwarijwellers@gmail.com</p>
    </section>
   </div>

   <hr size="2%" width="100%" color="purple">
<div class="bgimage">
  <table   width="100%" height="30%">
    <tr>
      <th width="25%"><img src="images/weaccept.png" width="100%"></th>
      <th width="50%">
         <h4><font color="gray">
          copyright@dnyneshwarijewells-2024
          you agree to the Terms of Use and Privacy Policy.
      dnyneshwarijewells® is a registered trademark of the (BSI) Foundation, Inc., Gold organization.
         </font></h4>
      </th>
      <th width="25%"><h4 ><font color="gray"><u>Con</u>nect With us..</font></h4>
                      <a href="https://www.instagram.com/dnyaneshwari_jwellers00/"><img src="images/ig.png" width="10%"></a>
                      <a href="https://www.facebook.com/"><img src="images/fb.png" width="10%"></a>
                      <a href="https://twitter.com/?lang=en"><img src="images/twit.png" width="10%"></a>
                      <a href="https://in.linkedin.com/"><img src="images/in.png" width="10%"></a>
                    </th>
    </tr>
  </table>  
  </div>
</font>
  </center>
  <hr size="2%" width="100%" color="purple">


</body>
</html>


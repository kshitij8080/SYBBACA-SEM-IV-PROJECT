<?php 
error_reporting(0);
  session_start();
   $con=mysqli_connect("localhost","root","");
     if($con==false)
     {
         die("error");
     }
     $_SESSION["p"]=$_POST["p1"];
     if(isset($_POST["p1"]))
     {
         header('location:booknow.php');
     }
     
     mysqli_close($con);
?>
<html>
  <head>
    <link rel="stylesheet" href="index.css">
    <style> 
      .bgimage
      {
        background-image:url(images/bgimage.jpg);
         
      }
      button
       {
          background-color:purple;
          border: 1;
          border-color: white;
          color: white;
          padding: 5%;
          text-align: center;
          font-family:Century Gothic;
       }  
       a
       {
         text-decoration:none;
       }
    </style>
      
  </head>
  <body>
    <font face="Century Gothic">
    <table width="100%" height="30%">
      <tr>
        <th width="20%">
        <img src="images/name2.png" loading="lazy" height="50%">
        </th>  
          <th width="60%">
            <center>
              <h1 ><u><font color="red">D</font>nya</u>neshwari <u><font color="red">J</font>we</u>llers  </h1>
              <h3 > Shrirampur:Taklibhan | Maharashtra | A.Nagar-413725</h3>
              <h3 >email:-dnyneshwarialankar@gmail.com &nbsp | &nbsp<font size="3"> GST-IN=07AAECR2971C1Z</font></h3> 
           </center>
          </th>
            <th width="20%">
              <img src="images/ganesha.png" loading="lazy" width="70%" > 
            </th>
      </tr>
    </table>
    
    <hr size="2%" width="100%" color="baby pink">
  
    <table  width="70%">
      <tr>
        <th><a href="index.php">Home</a></th>
        <th> <div class="dropdown">
              &nbsp&nbsp  <font color="purple"> Gold  </font> &nbsp&nbsp
              <div class="dropdown-content">
              <a href="stud.php">Studs</a>
              <a href="mangalsutra.php">Mangalsutra</a>
              <a href="necklace.php">Necklace</a>
              <a href="pendant.php">Pendant</a>
              </div>
         </div>
        </th>
        <th> 

        <div class="dropdown">
              &nbsp&nbsp <font color="purple">  Diamond  </font>  &nbsp&nbsp
              <div class="dropdown-content">
              <a href="d_stud.php">Studs</a>
              <a href="d_mangalsutra.php">Mangalsutra</a>
              <a href="d_rings.php">Rings</a>
              <a href="d_necklace.php">Necklace</a>
              </div>
         </div>

        </th>
        <th>

        <div class="dropdown">
              &nbsp&nbsp <font color="purple">  Silver  </font>  &nbsp&nbsp
              <div class="dropdown-content">
              <a href="Painjan.php">Painjan</a>
              <a href="rakhi.php">Silver Rakhi</a>
              </div>
         </div>

        </th>

        <th> <a href="https://bullions.co.in/"> &nbsp&nbsp  <font color="purple"> Online rates </font> &nbsp&nbsp </a> </th>
        <th> <a href="contact.php"> &nbsp&nbsp  <font color="purple"> Contact & Support </font> &nbsp&nbsp </a> </th>
        <th> <div class="dropdown">
              &nbsp&nbsp  <font color="purple"> Account  </font> &nbsp&nbsp
              <div class="dropdown-content">
              <a href="login.php">User</a>
              <a href="admin_login.php">Admin</a>
        
      </tr> 
    </table>
          
            <hr size="3%" width="100%" color="baby pink">
        
            
            
        <center>
          <form method="POST" action="">
        <table width="70%" cellspacing="20">
            <tr>
                <th><img src="necklace-images/n1.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="necklace-images/n2.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="necklace-images/n3.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="necklace-images/n4.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Swarajya 22KT Gold Mohan Mal Necklace<br>-<b>₹3,03,042</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Swarajya Gold Kolhapuri Saj Necklace<br>-<b>₹20,93,573</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Swarajya Gold Kolhapuri Saj Necklace<br>-<b>₹12,29,119</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Swarajya Gold Mohan Mal with Pendent Necklace<br>-<b>₹4,07,260</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="25">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="26">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="27">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="28">Book Now</button></th>
              </tr>
            <tr>
                <th><img src="necklace-images/n5.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="necklace-images/n6.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="necklace-images/n7.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
                <th><img src="necklace-images/n8.webp" width="250px" loading="lazy" style="border:3px double purple" ></td>
            </tr>
            <tr>
                <th><font face="Century Gothic" size="2" color="gray">Swarajya Gold Laxmi Har Necklace<br>-<b>₹1,68,449</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Swarajya Gold Bormal Necklace<br>-<b>₹68,087</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Swarajya Gold Mohan Mal Necklace<br>-<b>₹14,47,424</b></font></th>
                <th><font face="Century Gothic" size="2" color="gray">Swarajya Gold Bakuli Har Necklace<br>-<b>₹4,07,592</b></font></th>
            </tr>
            <tr>
            <th align="center"><button type="submit" name="p1" value="29">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="30">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="31">Book Now</button></th>
                <th align="center"><button type="submit" name="p1" value="32">Book Now</button></th>
              </tr>
            
        </table>
          </form>
        </center>

        <hr size="2%" width="100%" color="purple">
        <div class="bgimage">
          <table   width="100%" height="30%">
            <tr>
              <th width="25%"><img src="images/weaccept.png" width="100%"></th>
              <th width="50%">
                 <h4><font color="gray">
                  copyright@dnyneshwarijewells-2024
                  you agree to the Terms of Use and Privacy Policy.
              dnyneshwarijewells® is a registered trademark of the (BSI) Foundation, Inc., Gold organization.
                 </font></h4>
              </th>
              <th width="25%"><h4 ><font color="gray"><u>Con</u>nect With us..</font></h4>
                              <a href="https://www.instagram.com/dnyaneshwari_jwellers00/"><img src="images/ig.png" width="10%"></a>
                              <a href="https://www.facebook.com/"><img src="images/fb.png" width="10%"></a>
                              <a href="https://twitter.com/?lang=en"><img src="images/twit.png" width="10%"></a>
                              <a href="https://in.linkedin.com/"><img src="images/in.png" width="10%"></a>
              </th>
            </tr>
          </table>  
          </div>
        </font>
          </center>
          <hr size="2%" width="100%" color="purple">
    </body>
</html>
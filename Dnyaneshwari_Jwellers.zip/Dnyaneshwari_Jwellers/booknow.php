<?php
   error_reporting(0);
     session_start();
     $con=mysqli_connect("localhost","root","");
    if($con==false)
    {
      die("error");
    }
    $nm=$_POST["t1"];
    $mob=$_POST["t2"];
    $dt=$_POST["t3"];
    $pid=$_SESSION["p"];
    $no=0;
    mysqli_select_db($con,"project");
    if(isset($_POST["t4"]))
    {
    $res=mysqli_query($con,"insert into customer values('','$nm','$mob','$dt',$pid)");
      if($res==true)
      {
         echo"<script>alert('Your Product has been booked Successfully...!Thankyou.')
         window.location.href='index.php'; </script>";  
      }
    }
?> 
 <html>
<head>
<link rel="stylesheet" href="index.css">
    <title>Jewelry Shop - Contact & Support</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
         .book
         {
            background-image: url(images/bgimg.jpg);
         }
        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1em 0;
        }

        section {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            display: grid;
            grid-gap: 15px;
        }

        label {
            font-weight: bold;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: purple
        }
        a
       {
         text-decoration:none;
       }
       .bgimage
      {
        background-image:url(images/bgimage.jpg);
         
      }
      #product{
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#product td, #product th {
  border: 1px solid #ddd;
  padding: 8px;
}

#product tr:nth-child(even){background-color: #f2f2f2;}

#product tr:hover {background-color: #ddd;}

#product th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color:  #808080;
  color: white;
}
    </style>
</head>
<body>


<font face="Century Gothic">
<table width="100%" height="30%">
      <tr>
        <th width="20%">
        <img src="images/name2.png" loading="lazy" height="50%">
        </th>  
          <th width="60%">
            <center>
              <h1 ><u><font color="red">D</font>nya</u>neshwari <u><font color="red">J</font>we</u>llers  </h1>
              <h3 > Shrirampur:Taklibhan | Maharashtra | A.Nagar-413725</h3>
              <h3 >email:-dnyneshwarialankar@gmail.com &nbsp | &nbsp<font size="3"> GST-IN=07AAECR2971C1Z</font></h3> 
           </center>
          </th>
            <th width="20%">
              <img src="images/ganesha.png" loading="lazy" width="70%" > 
            </th>
      </tr>
    </table>
    
    <hr size="2%" width="100%" color="baby pink">
  
    <table  width="70%">
      <tr>
        <th><a href="index.php">Home</a></th>
        <th> <div class="dropdown">
              &nbsp&nbsp  <font color="purple"> Gold  </font> &nbsp&nbsp
              <div class="dropdown-content">
              <a href="stud.php">Studs</a>
              <a href="mangalsutra.php">Mangalsutra</a>
              <a href="necklace.php">Necklace</a>
              <a href="pendant.php">Pendant</a>
              </div>
         </div>
        </th>
        <th> 

        <div class="dropdown">
              &nbsp&nbsp <font color="purple">  Diamond  </font>  &nbsp&nbsp
              <div class="dropdown-content">
              <a href="d_stud.php">Studs</a>
              <a href="d_mangalsutra.php">Mangalsutra</a>
              <a href="d_rings.php">Rings</a>
              <a href="d_necklace.php">Necklace</a>
              </div>
         </div>

        </th>
        <th>

        <div class="dropdown">
              &nbsp&nbsp <font color="purple">  Silver  </font>  &nbsp&nbsp
              <div class="dropdown-content">
              <a href="Painjan.php">Painjan</a>
              <a href="rakhi.php">Silver Rakhi</a>
              </div>
         </div>

        </th>

        <th> <a href="https://bullions.co.in/"> &nbsp&nbsp  <font color="purple"> Online rates </font> &nbsp&nbsp </a> </th>
        <th> <a href="contact.php"> &nbsp&nbsp  <font color="purple"> Contact & Support </font> &nbsp&nbsp </a> </th>
        <th> <div class="dropdown">
              &nbsp&nbsp  <font color="purple"> Account  </font> &nbsp&nbsp
              <div class="dropdown-content">
              <a href="login.php">User</a>
              <a href="admin_login.php">Admin</a>        
      </tr> 
    </table>
    <hr size="2%" width="100%" color="baby pink">
    </font>


    
   <div class="book">
    <section>
        <h2 align="center"><u><font color="red">B</font>ook <font color="red">N</font>ow</u></h2>
        <form action="#" method="post">
            <label for="name">Name:</label>
            <input type="text" name="t1" required>

            <label for="phone no">Phone No:</label>
            <input type="text" name="t2" required>

            <label for="Date">Date:</label>
            <input type="date" name="t3" required>

            <label for="Product info">Product Information:</label>
            <?php
            error_reporting(0);
              $pid=$_SESSION["p"];
              mysqli_select_db($con,"project");
              $res=mysqli_query($con,"select * from product where pid='$pid'");
              echo"<table id=product>";
              echo"<tr><th>Product Name</th><th>Product Weight</th><th>Product Price</th><th>Product Caret</th>";
              while($row=mysqli_fetch_array($res))
              {
                 echo"<tr><td>".$row['pname'];
                 echo"<td>".$row['weight'];
                 echo"<td>".$row['price'];
                 echo"<td>".$row['crt']."</tr>";

              }
              mysqli_close($con);  
              echo"</table>";
            ?>
             
            <button type="submit" name="t4">Submit</button>
        </form>
    </section>

    
   </div>

   <hr size="2%" width="100%" color="purple">
<div class="bgimage">
  <table   width="100%" height="30%">
    <tr>
      <th width="25%"><img src="images/weaccept.png" width="100%"></th>
      <th width="50%">
         <h4><font color="gray">
          copyright@dnyneshwarijewells-2024
          you agree to the Terms of Use and Privacy Policy.
      dnyneshwarijewells® is a registered trademark of the (BSI) Foundation, Inc., Gold organization.
         </font></h4>
      </th>
      <th width="25%"><h4 ><font color="gray"><u>Con</u>nect With us..</font></h4>
                      <a href="https://www.instagram.com/dnyaneshwari_jwellers00/"><img src="images/ig.png" width="10%"></a>
                      <a href="https://www.facebook.com/"><img src="images/fb.png" width="10%"></a>
                      <a href="https://twitter.com/?lang=en"><img src="images/twit.png" width="10%"></a>
                      <a href="https://in.linkedin.com/"><img src="images/in.png" width="10%"></a>
                    </th>
    </tr>
  </table>  
  </div>
</font>
  </center>
  <hr size="2%" width="100%" color="purple">


</body>
</html>
<?php


?>